meson . builddir --cross-file cross-file.txt  --buildtype=minsize
