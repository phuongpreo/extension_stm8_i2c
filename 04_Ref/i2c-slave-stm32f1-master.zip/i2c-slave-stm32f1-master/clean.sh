rm -rf ./builddir
